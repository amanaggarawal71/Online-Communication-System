import database.connectivity.Connectivity;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "PasswordServlet", urlPatterns = {"/password"})
public class PasswordServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter pw=null;
        try{
        pw=resp.getWriter();
        String email=req.getParameter("txt1");
        long mobile=Long.parseLong(req.getParameter("txt2"));
        Connection con=Connectivity.getConnection();
        PreparedStatement pst=con.prepareStatement("select user_name,verified from chat_user where email=? and phone=?");
        pst.setString(1,email);
        pst.setLong(2,mobile);
        ResultSet rs=pst.executeQuery();
        String user_name="";
        if(rs.next()){
            String verified=rs.getString(2);
            if(verified.equals("N")){
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/Forgot.html");
            pw.println("<script>alert('Registration Process Incomplete,Please Complete Registration Process')</script>");
            rd.include(req,resp);
            }
            else{
            user_name=rs.getString(1);
            String password=getPassword();
            pst=con.prepareStatement("update chat_user set password=? where email=? and phone=?");
            pst.setString(1,password);
            pst.setString(2,email);
            pst.setLong(3,mobile);
            pst.executeQuery();
            rs.close();
            pst.close();
            Connectivity.closeConnection();
            sendEmail(email,password,user_name);
            resp.sendRedirect("Confirm2.jsp");
            }
        }
        else{
        RequestDispatcher rd=getServletContext().getRequestDispatcher("/Forgot.html");
        pw.println("<script>alert('Invalid Email or Phone,Try again')</script>");
        rd.include(req,resp);
        }
        rs.close();
        pst.close();
        Connectivity.closeConnection();
}
        catch(Exception e)
        {}
    }
static String getPassword(){
    String req="ABCDlmnop234567qrstuvEFGHIab234567cdefghijJKLMNOPQRSTUVWXYZkwxyz1234567890";
    String res="";
    for(int i=0;i<6;i++){
        int index=(int)((req.length())*Math.random());
        res+=req.charAt(index);
    }
    return res;
}
static void sendEmail(String email,String pass,String user_name){
        try{String user="amanaggarawal70";
        String password="9027904442";
        String sender="amanaggarawal70@gmail.com";
        String host="smtp.gmail.com";
        String port="465";
        Properties props=new Properties();
        props.put("mail.smtp.user",user);
        props.put("mail.smtp.password",password);
        props.put("mail.smtp.host",host);
        props.put("mail.smtp.port",port);
        props.put("mail.smtps.auth",true);
        Session ses=Session.getDefaultInstance(props);
        MimeMessage mime=new MimeMessage(ses);
        InternetAddress from=new InternetAddress(sender);
        InternetAddress to=new InternetAddress(email);
        mime.setSender(from);
        mime.setRecipient(Message.RecipientType.TO, to);
        mime.setSubject("Confirmation Email");
        InetAddress inet=InetAddress.getLocalHost();
        String ip=inet.getHostAddress();
        mime.setContent("Dear "+user_name+",<br><br>Greetings from portal!!<br><br>This is regarding password recovery from Chatbook.<br>Your new password is <b><mark>"+pass+"</b></mark>","text/html");
        Transport trans=ses.getTransport("smtps");
        trans.connect(host,user,password);
        trans.sendMessage(mime,mime.getAllRecipients());
        }
        catch(Exception e)
        {}
}
}
