import database.connectivity.Connectivity;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Properties;
import javax.imageio.ImageIO;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@MultipartConfig(maxFileSize = 10000000)
@WebServlet(urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter pw=null;
        try{
            pw=resp.getWriter();
            String fname=getValue(req.getPart("txt1"));
            String lname=getValue(req.getPart("txt2"));
            String name="";
            if(lname==null)
                name=fname;
            else
        name=fname+" "+lname;
        //pw.println(name);
        String email=getValue(req.getPart("txt3"));
        //pw.println(email);
        long mobile=Long.parseLong(getValue(req.getPart("txt4")));
        //pw.println(mobile);
        String gender=getValue(req.getPart("gender"));
        //pw.println(gender);
        Part p=req.getPart("photo");
        InputStream in=p.getInputStream();
        Connection con=Connectivity.getConnection();
        PreparedStatement pst=null;
        int n=0;
        String id=getRandomId();
        long time=System.currentTimeMillis();
        Timestamp ts=new Timestamp(time);
        if(in.read()==-1)//for checking whether inputstream is empty or not
        {
            pst=con.prepareStatement("insert into chat_user(user_name,email,phone,gender,signup_time,verified,id) values(?,?,?,?,?,?,?)"); 
            pst.setString(1,name);
            pst.setString(2, email);
            pst.setLong(3,mobile);
            pst.setString(4,gender);
            pst.setTimestamp(5, ts);
            pst.setString(6,"N");
            pst.setString(7,id);
            try{
            n=pst.executeUpdate();}
            catch(Exception e3){
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/Home.jsp");
        pw.println("<script>alert('Email id or phone already exist')</script>");
        rd.include(req,resp);
            }
        }
        else{
            pst=con.prepareStatement("insert into chat_user(user_name,email,phone,gender,profile_pic,signup_time,verified,id) values(?,?,?,?,?,?,?,?)");
            pst.setString(1,name);
            pst.setString(2, email);
            pst.setLong(3,mobile);
            pst.setString(4,gender);
            pst.setBlob(5, in);
            pst.setTimestamp(6, ts);
            pst.setString(7,"N");
            pst.setString(8,id);
            try{
            n=pst.executeUpdate();}
            catch(Exception e4)
            {
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/Home.jsp");
        pw.println("<script>alert('Email id or phone already exist')</script>");
        rd.include(req,resp);
            }
        }
        pst.close();
        Connectivity.closeConnection();
        in.close();
        HttpSession ses=req.getSession();
        ses.setAttribute("contact", mobile);
        //pw.println(n);
        //pw.println(id);
        try{
        sendEmail(email,id);}
        catch(Exception e2)
        {}
        resp.sendRedirect("Confirm.jsp?email="+email);
        /*if(in!=null){
        BufferedImage img=ImageIO.read(in);
        ImageIO.write(img,"JPG",resp.getOutputStream());}*/
        }
        catch(Exception e)
        {//resp.sendRedirect("Home.jsp");
         pw.println(e);   
        }
    }
    public static String getRandomId(){
            String id="";
            String req="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghiujklmnopqrstuvwxyz1234567890";
            int len=req.length(),i=0;
            char ch;
            for(i=0;i<20;i++)
            {
                ch=req.charAt((int)(len*Math.random()));
                   id+=ch;
            }
            return id;
    }
    public static void sendEmail(String email,String id){
    
        try{String user="amanaggarawal70";
        String password="9027904442";
        String sender="amanaggarawal70@gmail.com";
        String host="smtp.gmail.com";
        String port="465";
        Properties props=new Properties();
        props.put("mail.smtp.user",user);
        props.put("mail.smtp.password",password);
        props.put("mail.smtp.host",host);
        props.put("mail.smtp.port",port);
        props.put("mail.smtps.auth",true);
        Session ses=Session.getDefaultInstance(props);
        MimeMessage mime=new MimeMessage(ses);
        InternetAddress from=new InternetAddress(sender);
        InternetAddress to=new InternetAddress(email);
        mime.setSender(from);
        mime.setRecipient(Message.RecipientType.TO, to);
        mime.setSubject("Confirmation Email");
        InetAddress inet=InetAddress.getLocalHost();
        String ip=inet.getHostAddress();
         mime.setContent("Dear Sir/Mam,<br><br>Greetings from Portal!!!<br><br> This is confirmation mail from Chatbook, Please click on below link and verify yourself<br>http://"+ip+":47719/ChatProject/verify?email="+email+"&id="+id,"text/html");
        Transport trans=ses.getTransport("smtps");
        trans.connect(host,user,password);
        trans.sendMessage(mime,mime.getAllRecipients());
        }
        catch(Exception e)
        {}
        
    }
public static String getValue(Part part) throws IOException {
    BufferedReader reader = new BufferedReader(new InputStreamReader(part.getInputStream(), "UTF-8"));
    StringBuilder value = new StringBuilder();
    char[] buffer = new char[1024];
    for (int length = 0; (length = reader.read(buffer)) > 0;) {
        value.append(buffer, 0, length);
    }
    return value.toString();
           }
}
