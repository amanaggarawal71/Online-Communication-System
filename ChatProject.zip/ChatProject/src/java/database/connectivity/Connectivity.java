package database.connectivity;

import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class Connectivity {

    static Connection con=null;
    static InitialContext ctx=null;
    public static Connection getConnection(){
    try{
          ctx=new InitialContext();
       DataSource ds=(DataSource)ctx.lookup("jdbc/con");
        con=ds.getConnection();
        }
        catch(Exception e)
        {}
        return con;
    }
    public static void closeConnection(){
            try{
            ctx.close();
            con.close();
            }
            catch(Exception e)
            {}
    }
}
