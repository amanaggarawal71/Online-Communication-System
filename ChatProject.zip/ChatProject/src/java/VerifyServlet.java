import database.connectivity.Connectivity;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "VerifyServlet", urlPatterns = {"/verify"})
public class VerifyServlet extends HttpServlet {
 
    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       PrintWriter pw=resp.getWriter();
        try{
        String email=req.getParameter("email");
        String id=req.getParameter("id");
        if(email==null||id==null){
        resp.sendRedirect("Home.jsp");
        }
       // pw.println(id);
        Connection con=Connectivity.getConnection();
        Statement st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        //pw.println("hello world");
        String timeq="select extract(day from(sysdate-signup_time))*24*60+extract(hour from(sysdate-signup_time))*60+extract(minute from(sysdate-signup_time)) from chat_user where email='"+email+"' and id='"+id+"'";
        ResultSet rs=st.executeQuery(timeq);
        if(!rs.next()){
            rs.close();
            st.close();
            Connectivity.closeConnection();
        resp.sendRedirect("Home.jsp");
        }
        else{
        int time=rs.getInt(1);
        String verifyq="select verified from chat_user where email='"+email+"'and id='"+id+"'";
        rs=st.executeQuery(verifyq);
        rs.next();
        String verify=rs.getString(1);
        //pw.println(verify);
       // pw.println(time);
        if(verify.equals("N")){
        if(time<15)
        {
         String query="update chat_user set verified='Y' where email='"+email+"' and id='"+id+"'";
         st.executeUpdate(query);
               HttpSession ses=req.getSession();
               String contact=ses.getAttribute("contact").toString();
               //pw.println("contact");
             String password=getPassword();
          st.executeUpdate("update chat_user set password='"+password+"' where id='"+id+"'");
          String strurl="http://api.mVaayoo.com/mvaayooapi/MessageCompose?user=goelakshat13@gmail.com:123456&senderID=TEST%20SMS&receipientno="+contact+"&msgtxt=The_password_for_your_account_is_"+password+"&state=0"; 
          URL url=new URL(strurl);
          try{
          url.openStream(); }
          catch(Exception e1)
          {
              String deleteq="delete from chat_user where email='"+email+"'";
               int n=st.executeUpdate(deleteq);
              RequestDispatcher rd=getServletContext().getRequestDispatcher("/Home.jsp");
          pw.println("<script>alert('Invalid mobile number')</script>");
          rd.include(req,resp);}
          rs.close();
          st.close();
          Connectivity.closeConnection();
         resp.sendRedirect("Thankyou.html");
        }
        else{
            String deleteq="delete from chat_user where email='"+email+"'";
            int n=st.executeUpdate(deleteq);
        pw.println("<html><center><span style='color:red;font-family:tahoma;font-size:24px;'>The link you entered is Expired,Try again.<br>Click <a href='Home.jsp'>here</a> to go to home page.</span></center></html>");
        }
        }
        else{
           // pw.println(contact);
         pw.println("<html><center><span style='color:red;font-family:tahoma;font-size:24px;'>The link you entered is already verifed,Please login into your account.<br>Click <a href='Home.jsp'>here</a> to login.</span></center></html>");
        }
        }
        rs.close();
        st.close();
        Connectivity.closeConnection();
        }
        catch(Exception e)
        {pw.println(e);}
    }
    public static String getPassword()
    {
        String pass="";
        for(int i=0;i<4;i++)
        {
            int ch=(int)(10*Math.random());
            pass+=ch;
        }
        return pass;
    }
}
