package chat.room;

import java.util.*;

public class ChatRoom 
{
    Map<String, ChatUser> chatusers=
            new HashMap<String, ChatUser>();
    ArrayList<Message> messages=
            new ArrayList<Message>();   
    public void addChatUser(String userid,
            ChatUser cu,Message m)
    {
        chatusers.put(userid, cu);
        messages.add(m);
    }
    public void addMessage(Message m)
    {
        messages.add(m);
    }
    public Message[] getMessages()
    {
        Message m[]=
                new Message[messages.size()];
        Iterator<Message> itr=
                messages.iterator();
        int i=0;
        while(itr.hasNext())
        {
            m[i++]=itr.next();
        }
        return m;
    }
    public void deleteMessages(String userid)
    {
        Vector<Message> v=new Vector<Message>();
        Iterator<Message> itrs=messages.iterator();
        while(itrs.hasNext())
        {
            Message m=itrs.next();
            String uid=m.getUserid();
            if(uid.equals(userid))
            {
                v.add(m);
            }
        }
        for(int i=0;i<v.size();i++)
        {
            messages.remove(v.elementAt(i));
        }
        
    }
}
