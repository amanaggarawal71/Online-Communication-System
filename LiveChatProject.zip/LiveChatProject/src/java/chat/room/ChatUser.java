package chat.room;
public class ChatUser 
{
    private String name;
    private long logintime;

    public ChatUser(String name, 
            long logintime) {
        this.name = name;
        this.logintime = logintime;
    }

        
    public long getLogintime() {
        return logintime;
    }

    public void setLogintime(long logintime) {
        this.logintime = logintime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
