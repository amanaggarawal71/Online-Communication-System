package chat.room;
public class Message 
{
    private String text,userid;
    private long msgtime;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Message(String text, long msgtime,String userid) {
        this.text = text;
        this.msgtime = msgtime;
        this.userid=userid;
    }

    public long getMsgtime() {
        return msgtime;
    }

    public void setMsgtime(long msgtime) {
        this.msgtime = msgtime;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
