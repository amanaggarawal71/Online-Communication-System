import chat.room.ChatRoom;
import chat.room.ChatUser;
import chat.room.Message;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet 
{
    static ChatRoom cr=new ChatRoom();
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        String name=req.getParameter("name");
        Date d=new Date();
        long time=d.getTime();
        ChatUser cu=new ChatUser(name,time);
        Message m=new Message(name+" has joined the room", time,name);
        cr.addChatUser(name, cu, m);
        HttpSession ses=req.getSession();
        ses.setAttribute("chatroom", cr);
        ses.setAttribute("userid", name);
        resp.sendRedirect("chat.jsp");
    }   
}
